define((function(){"use strict";return{support:{snapshot:!1,export:!0,sharing:!1,exportData:!0,viewData:!0}}}));
